package KanbanProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KanbanProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(KanbanProjectApplication.class, args);
	}

}
